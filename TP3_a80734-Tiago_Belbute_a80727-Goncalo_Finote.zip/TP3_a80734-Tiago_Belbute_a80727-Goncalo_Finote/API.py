from flask import Flask, jsonify, request
import pickle

# Carregar todos os modelos e vetorizadores salvos
models = {
 'rf': {
  'model': pickle.load(open('rf_model.sav', 'rb')),
  'vectorizer': pickle.load(open('rf_count_vectorizer.sav', 'rb'))
 },

 # 'svm': {
 #     'model': pickle.load(open('svm_model.sav', 'rb')),
 #     'vectorizer': pickle.load(open('svm_count_vectorizer.sav', 'rb'))
 # },
  'knn': {
    'model': pickle.load(open('knn_model.sav', 'rb')),
    'vectorizer': pickle.load(open('knn_count_vectorizer.sav', 'rb'))
},
}

app = Flask(__name__)

# Rota para descrever o uso da API
@app.route("/usage")
def usage():
 return jsonify({
  "instructions": "Send a POST request to /classify with 'text' and 'model' as JSON data.",
  "example": '{"text": "I love this movie.", "model": "random_forest"}'
 })

# Rota para realizar classificações de sentimento
@app.route("/classifica", methods=["POST"])
def classify_text():
 try:
  # Extrai o texto e o nome do modelo do corpo da solicitação
  data = request.json
  text = data["text"]
  model_name = data["model"]

  if model_name not in models:
   return jsonify({"error": f"Model '{model_name}' not available."}), 400

  # Selecionar o modelo e vetorizador corretos
  model = models[model_name]["model"]
  vectorizer = models[model_name]["vectorizer"]

  # Vetoriza o texto
  text_vectorized = vectorizer.transform([text])

  # Realiza a classificação
  prediction = model.predict(text_vectorized)[0]
  sentiment_label = "positive" if prediction == 1 else "negative"

  # Retorna o resultado
  return jsonify({
   "model": model_name,
   "sentiment": sentiment_label,
   "text": text
  }), 200
 except Exception as e:
  return jsonify({"error": str(e)}), 500

# Tratamento de erro para rotas não encontradas (404)
@app.errorhandler(404)
def not_found(e):
 return jsonify({"error": "The requested URL was not found on the server."}), 404

if __name__ == "__main__":
 app.run(host='0.0.0.0', port=5007, debug=True)
